import pygame
from pygame.locals import *

#############################################################
class Collision():
  
    def __init__(self):
        pass

    def is_collide(self, rect1, rect2):
        self.rect1 = rect1
        self.rect2 = rect2

        return self.rect1.colliderect(self.rect2)
        
#############################################################
class Friction():

    PLAYER_FRICTION = 0.1

    def __init__(self):
        pass

    def goingbreak(self, is_turnright, is_turnleft, vx):
        self.friction = self.PLAYER_FRICTION
        if is_turnright:
            if vx >= 0:
                vx -= self.friction
                return vx
            else:
                self.friction = 0
                vx = 0
                return vx
        elif is_turnleft:
            if vx <= 0:
                vx += self.friction
                return vx
            else:
                self.friction = 0
                vx = 0
                return vx
        else:
            return vx

#############################################################
class Bouncing():

    def __init__(self):
        pass

    def bounce_Y(self, vy):
        return -vy

    def bounce_X(self, vx):
        return -vx