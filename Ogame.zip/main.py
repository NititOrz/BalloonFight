import pygame
from pygame.locals import *
from element import *
from gamephys import *

from gamelib import *

class BalloonGame(SimpleGame):
    BLACK = pygame.Color('black')
    WHITE = pygame.Color('white')
    GREEN = pygame.Color('green')
    WINDOW_WIDTH = 640
    WINDOW_HEIGHT = 480
    
    ############################################################# 
    # main operator from gamelib
    
    def __init__(self):#constructor
        super(BalloonGame, self).__init__('Balloon')
        self.player = Player(posX = 0,posY = 100)
        self.floor = [Floor(pos = (0, 360), width = 214, height = 120, pic = "big_floor.png"),
                      Floor(pos = (426, 360), width = 224, height = 120, pic = "big_floor.png"),
                      Floor(pos = (190, 250), width = 107, height = 50, pic = "mid2_floor.png"),
                      Floor(pos = (347, 200), width = 107, height = 50, pic = "mid2_floor.png"),
                      Floor(pos = (75, 50), width = 157, height = 50, pic = "mid1_floor.png"),
                      Floor(pos = (500, 50), width = 80, height = 100, pic = "smallheight_floor.png")]
        self.collide = Collision()
        self.bounce = Bouncing()
        
    def __init():
        super(BalloonGame, self).init()
    
    def update(self):
        self.handle_movement()
        self.player.moving()
        for x in self.floor:
            if self.collide.is_collide(self.player.getarect(), x.getarect()):
                self.player.stop_moving()
                x.floor_check(self.player, self.bounce)
                break
            else:
                self.player.set_g()

        self.bg_check()

    def render(self, surface):
        self.surface.fill(self.WHITE) # render background
        self.player.render(surface) # render player
        for x in self.floor:
            x.render(surface) # render floor
        pygame.display.flip()
        
        
    #############################################################
    # other operator

    def handle_movement(self): # handle player movement
        if self.is_key_pressed(K_UP):
            self.player.move_up()
        #elif self.is_key_pressed(K_DOWN):
        #    self.player.move_down()
        if self.is_key_pressed(K_LEFT):
            self.player.move_left()
        elif self.is_key_pressed(K_RIGHT):
            self.player.move_right()

    def bg_check(self):
        y = self.player.get_Y()
        x = self.player.get_X()
        vy = self.player.get_VY()
        if x + self.player.PLAYER_WIDTH/2 < 0: # left
            self.player.set_XY(posX = self.WINDOW_WIDTH - self.player.PLAYER_WIDTH + 15, posY = y) # 15 is various
        elif x - self.player.PLAYER_WIDTH/2 > self.WINDOW_WIDTH: # right
            self.player.set_XY(posX = 0 - self.player.PLAYER_WIDTH + 15, posY = y)
        if y + self.player.PLAYER_HEIGHT/2 + 5 < 0:
            self.player.set_XY(posX = x, posY = 0 - self.player.PLAYER_HEIGHT/2)
            vy = self.bounce.bounce_Y(vy)
            self.player.set_V(vx = self.player.get_VX(),vy = vy)
                        

        
def main():
    game = BalloonGame()
    game.run()
    
if __name__ == '__main__':
    main()    