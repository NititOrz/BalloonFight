import pygame
from pygame.locals import *
import gamelib
from gamelib import *
from gamephys import *

#############################################################
class Player():

    PLAYER_ACC_X = 0.5
    PLAYER_ACC_Y = 1.0
    PLAYER_G = 0.1
    PLAYER_WIDTH = 30.0
    PLAYER_HEIGHT = 40.0
    MAX_VELOCITY = 5.0
    
    def __init__(self, posX, posY, width = PLAYER_WIDTH, height = PLAYER_HEIGHT):
        self.posX = posX
        self.posY = posY
        self.width = width
        self.height = height
        self.rect = Rect(self.posX, self.posY, self.width, self.height)
        self.vx = 0
        self.vy = 0
        self.friction = Friction()
        self.turnright = False
        self.turnleft = False
        self.turn = False
         
    def render(self, surface):
        # render player pic
        iplayer = pygame.image.load("test.png")
        self.rect = surface.blit(iplayer, (self.posX, self.posY))

    def update(self):
        self.get()
        #########################################
        
    def move_up(self):
        if self.vy > -self.MAX_VELOCITY:
            self.vy -= self.PLAYER_ACC_Y
        else:
            self.vy = -self.MAX_VELOCITY + 0.1
        
    def move_down(self):
        self.vy = self.PLAYER_ACC_Y
    
    def move_right(self):
        if self.vx < self.MAX_VELOCITY:
            self.vx += self.PLAYER_ACC_X
        else:
            self.vx = self.MAX_VELOCITY - 0.1

        self.set_turnright()   

    def move_left(self):
        if self.vx > -self.MAX_VELOCITY:
            self.vx -= self.PLAYER_ACC_X
        else:
            self.vx = -self.MAX_VELOCITY + 0.1

        self.set_turnleft()

    def stop_moving(self):
        self.vy = 0
        self.g = 0
        self.vx = self.friction.goingbreak(self.turnright, self.turnleft, self.vx)

    def set_g(self):
        if self.vy < self.MAX_VELOCITY:
            self.vy += self.PLAYER_G
        else:
            self.vy = self.MAX_VELOCITY - 0.1

    def moving(self):
        self.posX += self.vx
        self.posY += self.vy

    def getarect(self):
        return self.rect

    def set_XY(self, posX, posY):
        self.posX = posX
        self.posY = posY

    def get_X(self):
        return self.posX

    def get_Y(self):
        return self.posY

    def set_V(self, vx, vy):
        self.vy = vy
        self.vx = vx

    def get_VX(self):
        return self.vx

    def get_VY(self):
        return self.vy

    def set_turnleft(self):
        self.turnleft = True
        self.turnright = False
        
    def set_turnright(self):
        self.turnright = True
        self.turnleft = False
        
#############################################################
class Floor():
    
    def __init__(self, pos, width, height, pic): # consturctor
        (self.posX, self.posY) = pos
        self.width = width
        self.height = height
        self.rect = Rect(self.posX, self.posY, self.width, self.height)
        self.floor = pygame.image.load(pic)
    
    def render(self, surface):
        surface.blit(self.floor, (self.posX, self.posY))

    def getarect(self):
        return self.rect

    def floor_check(self, player, bounce):
        self.bounce = bounce
        self.player = player
        self.y = player.get_Y()
        self.x = player.get_X()
        self.vy = player.get_VY()
        self.vx = player.get_VX()

        if  self.posY + self.height - 15 < self.y < self.posY + self.height : # bottom
            self.player.set_XY(posX = self.x, posY = self.posY + self.height)
            self.player.set_V(vx = self.vx,vy = self.bounce.bounce_Y(self.vy))

        elif self.posY < self.y + Player.PLAYER_HEIGHT < self.posY + 15: # top
            self.player.set_XY(posX = self.x, posY = self.posY - Player.PLAYER_HEIGHT + 1)

        elif self.posX < self.x + Player.PLAYER_WIDTH < self.posX + 15: # left
            self.player.set_XY(posX = self.posX - Player.PLAYER_WIDTH, posY = self.y)
            self.player.set_V(vx = self.bounce.bounce_X(self.vx),vy = self.vy)
            self.player.set_turnleft()

        elif self.posX + self.width -15 < self.x < self.posX + self.width: #right
            self.player.set_XY(posX = self.posX + self.width, posY = self.y)
            self.player.set_V(vx = self.bounce.bounce_X(self.vx),vy = self.vy)
            self.player.set_turnright()

#############################################################